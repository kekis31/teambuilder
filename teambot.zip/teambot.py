import random
from re import M

scoresraw = open("C:/Users/s2000925/Documents/Championship/teamgenerator/scores.txt", "r")
confsraw = open("C:/Users/s2000925/Documents/Championship/teamgenerator/confs.txt", "r")
mustsraw = open("C:/Users/s2000925/Documents/Championship/teamgenerator/musts.txt", "r")

c = confsraw.readlines()
confs = []
for cf in c:
    cf = cf.replace('\n', '')
    cf = cf.split(',')
    confs.append(cf)

m = mustsraw.readlines()
musts = []
for mu in m:
    mu = mu.replace('\n', '')
    mu = mu.split(',')
    musts.append(mu)

def print_team(team):
    teamtotalscore = (team[0][1] + team[1][1] + team[2][1])

    return f'{team[0][0]}, {team[1][0]}, {team[2][0]}, {teamtotalscore}'

def get_team_score(team):
    return team[0][1] + team[1][1] + team[2][1]

def check_all_team_conflicts(teams):

    for t in teams:
        if check_team_conflict(t):
            return True

    return False

def check_team_conflict(team):
    names = [team[0][0], team[1][0], team[2][0]]

    for conf in confs:
        if conf[0] in names and conf[1] in names:
            return True
    
    return False

def check_all_team_musts(teams):

    for t in teams:
        if not check_team_must(t):
            return False

    return True

def check_team_must(team):
    names = [team[0][0], team[1][0], team[2][0]]

    for must in musts:
        if must[0] in names and must[1] not in names:
            return False
        if must[1] in names and must[0] not in names:
            return False
    
    return True

s = scoresraw.readlines()

participants = []

for x in s:
    x = x.replace('\n','')
    x = x.split(',')
    name = x[0]
    season1score = int(x[1]) * 0.7
    season2score = int(x[2])

    averagescore = (season1score + season2score) / 2
    
    if (season1score == 0 or season2score == 0):
        averagescore = max(season1score, season2score)
    
    participants.append([name,averagescore])

bestteams = []
bestscore = 10000

while bestscore > 6000:
    randomorder = random.sample(participants, len(participants))

    team1 = [randomorder[0], randomorder[1], randomorder[2]]
    team2 = [randomorder[3], randomorder[4], randomorder[5]]
    team3 = [randomorder[6], randomorder[7], randomorder[8]]
    team4 = [randomorder[9], randomorder[10], randomorder[11]]
    
    teams = [team1,team2,team3,team4]

    if check_all_team_conflicts(teams):
        continue

    if not check_all_team_musts(teams):
        continue

    teamscores = [get_team_score(team1),get_team_score(team2),get_team_score(team3),get_team_score(team4)]
    scorediff = max(teamscores) - min(teamscores)

    if (scorediff < bestscore):
        bestteams = [team1,team2,team3,team4]
        bestscore = scorediff

print(f'{print_team(bestteams[0])}, \n{print_team(bestteams[1])}, \n{print_team(bestteams[2])}, \n{print_team(bestteams[3])}\nScore diff ({bestscore})')